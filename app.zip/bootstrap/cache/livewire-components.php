<?php return array (
  'world-stats' => 'App\\Http\\Livewire\\WorldStats',
);