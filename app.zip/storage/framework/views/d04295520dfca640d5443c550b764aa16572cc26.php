



<?php $__env->startSection('content'); ?>

<br>


<h2>STATISTIK COVID-19   
</h2>


<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('world-stats', [])->dom;
} elseif ($_instance->childHasBeenRendered('Us6TFeU')) {
    $componentId = $_instance->getRenderedChildComponentId('Us6TFeU');
    $componentTag = $_instance->getRenderedChildComponentTagName('Us6TFeU');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Us6TFeU');
} else {
    $response = \Livewire\Livewire::mount('world-stats', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('Us6TFeU', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>



<!-- <div class="row pt-6">
							
                            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
								<div class="card bg-warning img-card box-primary-shadow">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
												<p class="text-white mb-0">TOTAL POSITIF</p>
												<h2 class="mb-0 number-font"><?php echo e($data1['value']); ?></h2>
												<p class="text-white mb-0">ORANG</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
								<div class="card bg-success img-card box-secondary-shadow">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
												<p class="text-white mb-0">TOTAL SEMBUH</p>
												<h2 class="mb-0 number-font"><?php echo e($data2['value']); ?></h2>
												<p class="text-white mb-0">ORANG</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
								<div class="card  bg-danger img-card box-success-shadow">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
												<p class="text-white mb-0">TOTAL MENINGGAL</p>
												<h2 class="mb-0 number-font"><?php echo e($data3['value']); ?></h2>
												<p class="text-white mb-0">ORANG</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</div>


<br> -->


<table class="table table-sm table-striped">
    <thead class="thead-dark">
    <tr>
    <th scope="col">#</th>
    <th  scope="col">Negara</th>
    <th class="text-center"">Positif</th>
    <th class="text-center">Meninggal</th>
    <th class="text-center">Sembuh</th>

    </tr>
    </thead>
    <tbody>

    <?php

    $no = 0;

    ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php

    $no++;

    ?>

    <tr>
    <th scope="row"><?php echo e($no); ?></th>
    <td><a href="/country/<?php echo e($d['attributes']['Country_Region']); ?>" ><?php echo e($d['attributes']['Country_Region']); ?></a></td>
    <td class="text-center"><?php echo e($d['attributes']['Confirmed']); ?></td>
    <td class="text-center"><?php echo e($d['attributes']['Deaths']); ?></td>
    <td class="text-center"><?php echo e($d['attributes']['Recovered']); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    </table>









<hr>

    



<?php $__env->stopSection(); ?>








                       

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\covid\resources\views/index.blade.php ENDPATH**/ ?>