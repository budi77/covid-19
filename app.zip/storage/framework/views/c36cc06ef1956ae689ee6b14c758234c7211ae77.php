


<?php $__env->startSection('content'); ?>
<br>

<h3 class="text-uppercase text-strong">FAQ</h3>
<br>
<div class="list-group">

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <a href="#" class="list-group-item list-group-item-action">
    <div class="d-flex w-100 justify-content-between">
      <h4 class="mb-1 text-strong text-danger"><?php echo e($d['question']); ?></h5>
      <!-- <small>3 days ago</small> -->
    </div>
    <p class="mb-1"><?php echo e($d['answer']); ?></p>
    <!-- <small>Donec id elit non mi porta.</small> -->
  </a>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\covid\resources\views//faq.blade.php ENDPATH**/ ?>