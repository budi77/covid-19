



<?php $__env->startSection('content'); ?>

<div>
<br>
<h4>BERDASARKAN NEGARA</h4>
<br>
<form action="<?php echo e(route('search')); ?>" method="post" class="form-inline my-2 my-lg-0">

    <?php echo csrf_field(); ?>
     

      <select class="form-control mr-sm-2 form-control-sm" id="exampleSelect1" name="country">
        <?php $__currentLoopData = $negara_sorted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($d['Country_Region']); ?>"><?php echo e($d['Country_Region']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button class="btn btn-success btn-sm my-2 my-sm-0" type="submit">Lihat</button>
    

    </form>
</div>
<br>

<h4 class="text-uppercase text-center"><?php echo e($country); ?></h4>
    
    

    <div id="app">
            <?php echo $chart->container(); ?>

        </div>

        <div class="row mt-6">
											<div class="col text-center">
												<h5 class="font-weight-normal mt-2">KES HARI INI</h5>
												<h3 class="text-xxl mb-1 social-content  number-font text-info"> <?php echo e($todayCases); ?></h3>
												<p class="mb-0 text-muted"><span class="text-lg font-weight-700"></span>ORANG</p>
												
											</div>
											<div class="col text-center">
												<h5 class="font-weight-normal mt-2">MENINGGAL HARI INI</h5>
												<h3 class="text-xxl mb-1 social-content danger number-font text-info"> <?php echo e($todayDeaths); ?></h3>
												<p class="mb-0 text-muted"><span class="text-lg font-weight-700"></span>ORANG</p>
												
											</div>
											<div class="col text-center">
												<h5 class="font-weight-normal mt-2">AKTIF</h5>
												<h3 class="text-xxl mb-1 social-content  number-font text-info"> <?php echo e($active); ?></h3>
												<p class="mb-0 text-muted"><span class="text-lg font-weight-700"></span>ORANG</p>
											
											</div>

                      <div class="col text-center">
												<h5 class="font-weight-normal mt-2">KRITIKAL</h5>
												<h3 class="text-xxl mb-1 social-content  number-font text-info"> <?php echo e($critical); ?></h3>
												<p class="mb-0 text-muted"><span class="text-lg font-weight-700"></span>ORANG</p>
											
											</div>
											<!-- <div class="chart-wrapper">
											<canvas id="deals" class="chart-dropshadow-success chartjs-render-monitor" hidden="" height="113" style="display: block; height: 84px; width: 0px;" width="0"></canvas>
										</div> -->
										</div>

<br>



<table class="table table-sm table-striped">
  <thead class="thead-dark">
    <tr>
      <th class="text-center" scope="col">Tarikh</th>
      <th class="text-center" scope="col">Positif</th>
      <th class="text-center" scope="col">Sembuh</th>
      <th class="text-center" scope="col">Meninggal</th>

    </tr>
  </thead>
  <tbody>


  <?php $__currentLoopData = $cntry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <td class="text-center"><?php echo e($c['date']); ?></td>
      <td class="text-center"><?php echo e($c['confirmed']); ?></td>
      <td class="text-center"><?php echo e($c['recovered']); ?></td>
      <td class="text-center"><?php echo e($c['deaths']); ?></td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>


<hr>

<?php echo $chart->script(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\covid\resources\views/country.blade.php ENDPATH**/ ?>