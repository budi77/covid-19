


<?php $__env->startSection('content'); ?>
<br>

<h4 class="text-uppercase text-strong">NEGARA ASEAN</h4>

<div class="row">

    <div class="col-sm-4">

    <br>
    <br>

    <table class="table table-sm table-striped">
    <thead class="thead-dark">
    <tr>
    <th  scope="col">Negara</th>
    <th class="text-center"">Positif</th>
    <th class="text-center">Meninggal</th>
    <th class="text-center">Sembuh</th>

    </tr>
    </thead>
    <tbody>

    <?php

    $no = 0;

    ?>

    <?php $__currentLoopData = $negara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php

    $no++;

    ?>

    <tr>
    <td><a href="/country/<?php echo e($d['Country_Region']); ?>" ><?php echo e($d['Country_Region']); ?></a></td>
    <td class="text-center"><?php echo e($d['Confirmed']); ?></td>
    <td class="text-center"><?php echo e($d['Deaths']); ?></td>
    <td class="text-center"><?php echo e($d['Recovered']); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    </table>







    </div>

    <div class="col-sm-8">

    <div id="app">
            <?php echo $chart->container(); ?>


    </div>

    <br>

    <div class="text-center">
    <div class="btn-group" role="group" aria-label="Basic example">
        <a href="/asean/confirmed" class="btn btn-warning btn-sm">Confirmed</a>
        <a href="/asean/deaths" class="btn btn-danger btn-sm">Deaths</a>
        <a href="/asean/recovered" class="btn btn-success btn-sm">Recovered</a>
    </div>
</div>	
    
    
    </div>
</div>
    
    

    


<hr>

	

<br>
<br>

<?php echo $chart->script(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\covid\resources\views/asean.blade.php ENDPATH**/ ?>